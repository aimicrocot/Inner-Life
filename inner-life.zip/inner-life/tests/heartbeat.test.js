import test from 'node:test';
import assert from 'node:assert/strict';
import { HeartbeatEngine } from '../src/heartbeat.js';
import { mergeSettings, newProfile } from '../src/settings.js';
import { emptyCharData, migrateCharData } from '../src/store.js';

const T0 = new Date(2026, 5, 1, 12, 0).getTime();

function setup({ replies, messages = 6, settingsPatch = {}, chatId = 'chat1' } = {}) {
    const settings = mergeSettings({ enabled: true, characters: { 'A.png': { enabled: true } }, ...settingsPatch });
    settings.heartbeat.debounceSec = 0;
    let now = T0;
    const stored = {};
    const calls = [];
    const msgs = Array.from({ length: messages }, (_, i) => ({ idx: i, name: i % 2 ? 'Alice' : 'Bob', is_user: !(i % 2), mes: `message ${i}` }));
    const env = { chatId, avatar: 'A.png', msgs };
    const deps = {
        now: () => now,
        getSettings: () => settings,
        saveSettings: () => {},
        getSnapshot: () => ({ chatId: env.chatId, avatar: env.avatar, charName: 'Alice', userName: 'Bob', card: { description: 'A thoughtful pilot' }, generating: false, messages: env.msgs }),
        loadChar: async (avatar, name) => (stored[avatar] ||= migrateCharData(emptyCharData(avatar, name, T0), avatar, name, T0)),
        saveChar: () => {},
        callModel: async (profile, req) => {
            const kind = req.system.includes('inner mind') ? 'heartbeat' : req.system.includes('diary entry') ? 'diary' : 'memory';
            calls.push({ kind, profile: profile.id, req });
            const r = replies[kind];
            if (r instanceof Error) throw r;
            return { text: typeof r === 'function' ? r(req) : r };
        },
        notify: () => {},
        redact: (t) => t.replace(/SECRETKEY/g, '***'),
    };
    const engine = new HeartbeatEngine(deps);
    return { engine, settings, stored, calls, env, advance: (ms) => { now += ms; }, getNow: () => now };
}

const HB_ALL = JSON.stringify({ mood: 'warm', diary: true, diary_focus: 'the promise', remember: true, working_note: 'wants to keep the promise' });
const DIARY = JSON.stringify({ text: 'Он пообещал вернуться, и я ему верю.', mood: 'тепло', tags: ['обещание'] });
const MEM = JSON.stringify({ memories: [{ text: 'Bob promised to come back tomorrow', type: 'episodic', confidence: 'confirmed', importance: 4 }] });

test('first sight of a chat only sets a baseline (no model calls)', async () => {
    const h = setup({ replies: {} });
    const r = await h.engine.tick();
    assert.equal(r.reason, 'baseline-set');
    assert.equal(h.calls.length, 0);
    assert.equal(h.stored['A.png'].state.processed.chat1.idx, 6);
});

test('does nothing (and calls no model) below the new-message threshold', async () => {
    const h = setup({ replies: {} });
    await h.engine.tick();
    h.advance(11 * 60000);
    h.env.msgs.push({ idx: 6, name: 'Bob', is_user: true, mes: 'hello' });
    const r = await h.engine.tick();
    assert.match(r.reason, /not-enough-new-messages/);
    assert.equal(h.calls.length, 0);
});

test('full cycle: decision -> diary + memory, each on its own model, state persisted', async () => {
    const h = setup({ replies: { heartbeat: HB_ALL, diary: DIARY, memory: MEM } });
    const cheap = newProfile('openai'); cheap.id = 'cheap';
    h.settings.models.profiles.push(cheap);
    h.settings.models.assign.heartbeat = 'cheap';
    h.settings.models.assign.memory = 'cheap';
    await h.engine.tick(); // baseline
    h.advance(11 * 60000);
    for (let i = 6; i < 11; i++) h.env.msgs.push({ idx: i, name: i % 2 ? 'Alice' : 'Bob', is_user: !(i % 2), mes: `new ${i}` });
    const r = await h.engine.tick();
    assert.equal(r.status, 'ok');
    const d = h.stored['A.png'];
    assert.equal(d.diary.length, 1);
    assert.equal(d.memories.length, 1);
    assert.equal(d.state.mood, 'warm');
    assert.equal(d.state.processed.chat1.idx, 11);
    assert.deepEqual(h.calls.map(c => [c.kind, c.profile]), [['heartbeat', 'cheap'], ['diary', 'current'], ['memory', 'cheap']]);
    assert.equal(h.settings.usage.dayCalls, 3);
    // new messages were consumed: next tick does nothing
    h.advance(11 * 60000);
    assert.match((await h.engine.tick()).reason, /not-enough/);
});

test('model decides "nothing to do": one cheap call, no diary, no memory', async () => {
    const h = setup({ replies: { heartbeat: JSON.stringify({ mood: 'calm', diary: false, remember: false, working_note: '' }) } });
    await h.engine.tick();
    h.advance(11 * 60000);
    for (let i = 6; i < 11; i++) h.env.msgs.push({ idx: i, name: 'Bob', is_user: true, mes: 'small talk' });
    const r = await h.engine.tick();
    assert.equal(r.status, 'ok');
    assert.equal(h.calls.length, 1);
    assert.equal(h.stored['A.png'].diary.length, 0);
});

test('diary anti-spam gap is enforced for automatic cycles', async () => {
    const h = setup({ replies: { heartbeat: HB_ALL, diary: DIARY, memory: JSON.stringify({ memories: [] }) } });
    await h.engine.tick();
    const pushNew = (from) => { for (let i = from; i < from + 5; i++) h.env.msgs.push({ idx: i, name: 'Bob', is_user: true, mes: `m${i}` }); };
    h.advance(11 * 60000); pushNew(6);
    await h.engine.tick();
    assert.equal(h.stored['A.png'].diary.length, 1);
    h.advance(11 * 60000); pushNew(11); // only 11 min after the last diary entry; gap is 30
    await h.engine.tick();
    assert.equal(h.stored['A.png'].diary.length, 1);
});

test('budget exhaustion stops calls and is not counted as a failure', async () => {
    const h = setup({ replies: { heartbeat: HB_ALL, diary: DIARY, memory: MEM } });
    h.settings.limits.maxCallsPerHour = 1;
    await h.engine.tick();
    h.advance(11 * 60000);
    for (let i = 6; i < 11; i++) h.env.msgs.push({ idx: i, name: 'Bob', is_user: true, mes: `m${i}` });
    const r = await h.engine.tick();
    assert.equal(r.status, 'skipped');
    assert.match(r.reason, /budget/);
    assert.equal(h.engine.failures, 0);
    assert.equal(h.calls.length, 1);
    assert.equal(h.stored['A.png'].diary.length, 0);
});

test('kill switch for background calls blocks the first call', async () => {
    const h = setup({ replies: { heartbeat: HB_ALL } });
    h.settings.limits.backgroundCallsEnabled = false;
    await h.engine.tick();
    h.advance(11 * 60000);
    for (let i = 6; i < 11; i++) h.env.msgs.push({ idx: i, name: 'Bob', is_user: true, mes: `m${i}` });
    await h.engine.tick();
    assert.equal(h.calls.length, 0);
});

test('API errors: backoff, secret redaction, auto-pause after repeated failures', async () => {
    const h = setup({ replies: { heartbeat: new Error('401 invalid key SECRETKEY') } });
    await h.engine.tick();
    for (let i = 6; i < 12; i++) h.env.msgs.push({ idx: i, name: 'Bob', is_user: true, mes: `m${i}` });
    h.advance(11 * 60000);
    const r = await h.engine.tick();
    assert.equal(r.status, 'error');
    assert.ok(!r.error.includes('SECRETKEY'));
    assert.equal((await h.engine.tick()).reason, 'backoff');
    for (let n = 0; n < 4; n++) { h.advance(3 * 3600000); await h.engine.tick(); }
    assert.equal(h.settings.heartbeat.paused, true);
    assert.equal((await h.engine.tick()).reason, 'paused');
    assert.ok(!JSON.stringify(h.stored['A.png'].state.log).includes('SECRETKEY'));
    h.engine.resume();
    assert.equal(h.settings.heartbeat.paused, false);
});

test('unparseable decision is an error, but unparseable diary is not fatal', async () => {
    const bad = setup({ replies: { heartbeat: 'I think the character feels good!' } });
    await bad.engine.tick();
    for (let i = 6; i < 12; i++) bad.env.msgs.push({ idx: i, name: 'Bob', is_user: true, mes: 'x' });
    bad.advance(11 * 60000);
    assert.equal((await bad.engine.tick()).status, 'error');

    const ok = setup({ replies: { heartbeat: HB_ALL, diary: '{broken', memory: MEM } });
    await ok.engine.tick();
    for (let i = 6; i < 12; i++) ok.env.msgs.push({ idx: i, name: 'Bob', is_user: true, mes: 'x' });
    ok.advance(11 * 60000);
    const r = await ok.engine.tick();
    assert.equal(r.status, 'ok');
    assert.equal(ok.stored['A.png'].diary.length, 0);
    assert.equal(ok.stored['A.png'].memories.length, 1);
});

test('results are discarded if the chat changed during the cycle', async () => {
    const h = setup({ replies: { heartbeat: (req) => { h.env.chatId = 'other-chat'; return HB_ALL; }, diary: DIARY, memory: MEM } });
    await h.engine.tick();
    for (let i = 6; i < 12; i++) h.env.msgs.push({ idx: i, name: 'Bob', is_user: true, mes: 'x' });
    h.advance(11 * 60000);
    const r = await h.engine.tick();
    assert.equal(r.reason, 'discarded-chat-changed');
    assert.equal(h.stored['A.png'].diary.length, 0);
    assert.equal(h.stored['A.png'].memories.length, 0);
});

test('no parallel cycles', async () => {
    let release;
    const gate = new Promise(r => { release = r; });
    const h = setup({ replies: { heartbeat: () => HB_ALL } });
    const orig = h.engine.deps.callModel;
    h.engine.deps.callModel = async (...a) => { await gate; return orig(...a); };
    await h.engine.tick();
    for (let i = 6; i < 12; i++) h.env.msgs.push({ idx: i, name: 'Bob', is_user: true, mes: 'x' });
    h.advance(11 * 60000);
    const first = h.engine.runCycle({ manual: false });
    await new Promise(r => setTimeout(r, 5));
    assert.equal((await h.engine.runCycle({ manual: true })).reason, 'busy');
    release();
    await first;
});

test('model correction updates a memory, but never overwrites one the user edited', async () => {
    const h = setup({ replies: { heartbeat: JSON.stringify({ mood: 'm', diary: false, remember: true }), memory: (req) => {
        const ids = [...req.user.matchAll(/\[(m_[a-z0-9]+)\]/g)].map(x => x[1]);
        return JSON.stringify({ memories: ids.map(id => ({ text: 'Corrected: Bob lives in Hamburg now', updates: id, importance: 3 })) });
    } } });
    await h.engine.tick();
    const d = h.stored['A.png'];
    const { addMemory } = await import('../src/store.js');
    const a = addMemory(d, { text: 'Bob lives in Berlin', importance: 3 }, T0).memory;
    for (let i = 6; i < 12; i++) h.env.msgs.push({ idx: i, name: 'Bob', is_user: true, mes: 'I moved to Hamburg' });
    h.advance(11 * 60000);
    await h.engine.tick();
    assert.match(a.text, /Hamburg/);
    assert.equal(a.history.at(-1).text, 'Bob lives in Berlin');

    const b = addMemory(d, { text: 'Bob drinks green tea daily', importance: 3 }, T0).memory;
    b.userEdited = true;
    for (let i = 12; i < 18; i++) h.env.msgs.push({ idx: i, name: 'Bob', is_user: true, mes: 'tea?' });
    h.advance(11 * 60000);
    await h.engine.tick();
    assert.equal(b.text, 'Bob drinks green tea daily');
});
