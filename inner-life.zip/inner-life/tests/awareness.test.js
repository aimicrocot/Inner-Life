import test from 'node:test';
import assert from 'node:assert/strict';
import { findGaps, findReturnGap } from '../src/time.js';
import { addUnsaid, deleteUnsaid, expireUnsaid, heldUnsaid, pruneUnsaid, resolveUnsaid, unsaidForInjection } from '../src/unsaid.js';
import { addDiaryEntry, emptyCharData, migrateCharData, relevantDiary } from '../src/store.js';
import { buildDiaryPrompt, buildHeartbeatPrompt, buildIdlePrompt, buildInjection, normalizeDiaryResult, normalizeHeartbeatResult, normalizeIdleResult } from '../src/prompts.js';

const T = new Date(2026, 5, 1, 14, 0).getTime();
const H = 3600000, DAY = 86400000;
const fresh = () => emptyCharData('A.png', 'Alice', T);

// ---------------- time awareness ----------------

const msg = (is_user, ts, mes = 'm') => ({ is_user, ts, mes, name: is_user ? 'Bob' : 'Alice' });

test('return gap: user comes back after a long silence', () => {
    const m = [msg(false, T - 10 * H), msg(true, T)];
    const r = findReturnGap(m, 6 * H);
    assert.equal(r.gapMs, 10 * H);
    assert.equal(findReturnGap(m, 12 * H), null);
});

test('return gap: still noticed while the first reply is generated or regenerated, forgotten once the chat moves on', () => {
    const base = [msg(false, T - 10 * H), msg(true, T)];
    assert.ok(findReturnGap([...base, msg(false, T + 1000)], 6 * H));
    assert.equal(findReturnGap([...base, msg(false, T + 1000), msg(false, T + 2000)], 6 * H), null);
});

test('return gap: unknown timestamps, no user message or a short chat never produce a gap', () => {
    assert.equal(findReturnGap([msg(false, 0), msg(true, T)], H), null);
    assert.equal(findReturnGap([msg(false, T - 10 * H), msg(false, T)], H), null);
    assert.equal(findReturnGap([msg(true, T)], H), null);
    assert.equal(findReturnGap([], H), null);
});

test('transcript gaps: largest first, limited, only above the threshold', () => {
    const m = [msg(true, T), msg(false, T + 7 * H), msg(true, T + 7 * H + 60000), msg(false, T + 7 * H + 60000 + 30 * H), msg(true, T + 9999 * H)];
    const g = findGaps(m, 6 * H, 2);
    assert.equal(g.length, 2);
    assert.ok(g[0].gapMs > g[1].gapMs);
    assert.equal(findGaps(m, 10000 * H).length, 0);
});

// ---------------- unsaid ----------------

const L = { maxHeld: 3 };

test('unsaid: validation, duplicates (held and recently voiced), and the cap on held thoughts', () => {
    const d = fresh();
    assert.equal(addUnsaid(d, { text: 'hi' }, T, L).reason, 'text-too-short');
    const a = addUnsaid(d, { text: 'I want to ask whether he still thinks about his old home', why: 'afraid to pry' }, T, L);
    assert.equal(a.action, 'added');
    assert.equal(addUnsaid(d, { text: 'I want to ask if he still thinks about his old home' }, T, L).reason, 'duplicate-or-recently-resolved');
    resolveUnsaid(d, [a.item.id], T + 1000, 'voiced');
    assert.equal(addUnsaid(d, { text: 'I want to ask whether he still thinks about his old home' }, T + 2000, L).reason, 'duplicate-or-recently-resolved');
    assert.equal(addUnsaid(d, { text: 'I want to ask whether he still thinks about his old home' }, T + 20 * DAY, L).action, 'added');
    addUnsaid(d, { text: 'I never told him how scared I was during the storm' }, T + 21 * DAY, L);
    addUnsaid(d, { text: 'I wonder if he would come with me to the lighthouse' }, T + 21 * DAY, L);
    assert.equal(addUnsaid(d, { text: 'Something entirely different about gardening tools' }, T + 21 * DAY, L).reason, 'too-many-held');
});

test('unsaid: resolve, fade away, prune, delete, injection order', () => {
    const d = fresh();
    const x = addUnsaid(d, { text: 'I would like to apologise for the harsh remark yesterday' }, T, L).item;
    const y = addUnsaid(d, { text: 'I am curious about the scar on his hand' }, T + 5000, L).item;
    assert.equal(unsaidForInjection(d, 1)[0].id, y.id);
    assert.equal(resolveUnsaid(d, [x.id, 'ghost'], T + 6000, 'voiced', 'said it'), 1);
    assert.equal(resolveUnsaid(d, [x.id], T + 7000), 0); // already resolved
    assert.equal(expireUnsaid(d, T + 5 * DAY, 14), 0);
    assert.equal(expireUnsaid(d, T + 15 * DAY, 14), 1);
    assert.equal(y.status, 'dropped');
    assert.equal(heldUnsaid(d).length, 0);
    for (let i = 0; i < 5; i++) d.unsaid.push({ id: `z${i}`, status: 'voiced', resolvedAt: i, updatedAt: i, text: 'x', createdAt: 0 });
    assert.ok(pruneUnsaid(d, 2) > 0);
    assert.equal(deleteUnsaid(d, d.unsaid[0].id), true);
});

test('migrate adds the unsaid list to old data files', () => {
    const d = migrateCharData({ diary: [], memories: [], goals: [], state: {} }, 'A.png', 'Alice', T);
    assert.deepEqual(d.unsaid, []);
});

// ---------------- diary revisit ----------------

test('revisit never rewrites the original: a new entry points back, the old one is only marked', () => {
    const d = fresh();
    const old = addDiaryEntry(d, { text: 'I think he lied to me about the letter.' }, T);
    const original = old.text;
    const re = addDiaryEntry(d, { text: 'I was wrong about the letter; he forgot, he did not lie.', revisit: { of: old.id, stance: 'withdrawn' } }, T + DAY);
    assert.equal(old.text, original);
    assert.deepEqual(old.revisedBy, [re.id]);
    assert.deepEqual(re.revisit, { of: old.id, stance: 'withdrawn' });
    assert.equal(d.diary.length, 2);
});

test('revisit: unknown target is ignored, bad stance defaults to "revised"', () => {
    const d = fresh();
    const a = addDiaryEntry(d, { text: 'First thought of the day here.' }, T);
    assert.equal(addDiaryEntry(d, { text: 'A thought pointing nowhere.', revisit: { of: 'ghost' } }, T + 1).revisit, null);
    assert.equal(addDiaryEntry(d, { text: 'A thought pointing back.', revisit: { of: a.id, stance: 'banana' } }, T + 2).revisit.stance, 'revised');
});

test('relevantDiary finds older related entries and honours exclusions', () => {
    const d = fresh();
    const e1 = addDiaryEntry(d, { text: 'He told me about the lighthouse and his grandfather.' }, T);
    addDiaryEntry(d, { text: 'We argued about nothing important at all today.' }, T + 1000);
    const e3 = addDiaryEntry(d, { text: 'The lighthouse keeps coming back into our talks.' }, T + 2000);
    const r = relevantDiary(d, 'Do you remember the lighthouse?', { limit: 3, excludeIds: [e3.id], now: T + 3000 });
    assert.deepEqual(r.map(x => x.id), [e1.id]);
    assert.deepEqual(relevantDiary(d, '', {}), []);
});

// ---------------- prompts / validators ----------------

test('heartbeat decision: revisit id, unsaid and resolved ids are validated', () => {
    const r = normalizeHeartbeatResult({ mood: 'm', revisit_id: 'd_1', unsaid: { text: 'I want to ask about his scar', why: 'tact' }, unsaid_resolved: ['u1', 5, 'u2'] });
    assert.equal(r.revisitId, 'd_1');
    assert.equal(r.unsaid.why, 'tact');
    assert.deepEqual(r.unsaidResolved, ['u1', 'u2']);
    assert.equal(normalizeHeartbeatResult({ revisit_id: 'null', unsaid: { text: 'x' } }).revisitId, null);
    assert.equal(normalizeHeartbeatResult({ unsaid: { text: 'x' } }).unsaid, null);
    assert.equal(normalizeHeartbeatResult({ unsaid: 'free text' }).unsaid, null);
});

test('diary result keeps the stance only when valid; idle result carries the unsaid id', () => {
    assert.equal(normalizeDiaryResult({ text: 'Now I see it differently.', stance: 'revised' }).stance, 'revised');
    assert.equal(normalizeDiaryResult({ text: 'Now I see it differently.', stance: 'whatever' }).stance, '');
    assert.equal(normalizeIdleResult({ reach_out: true, unsaid_id: 'u9' }).unsaidId, 'u9');
    assert.equal(normalizeIdleResult({ reach_out: true, unsaid_id: 'null' }).unsaidId, null);
});

test('prompts expose candidate diary ids, unspoken items, silences and the revisit block', () => {
    const ctx = {
        charName: 'Alice', userName: 'Bob', card: null, cardChars: 0, transcript: 'Bob: hi', now: T, lastDiaryTs: 0, silenceMs: 5 * H,
        recentDiary: [], memories: [], goals: [],
        unsaid: [{ id: 'u1', text: 'ask about the scar', why: 'tact' }],
        revisitCandidates: [{ id: 'd_old', ts: T - DAY, text: 'I think he lied about the letter' }],
        gaps: [{ gapMs: 30 * H, after: { mes: 'goodnight' }, before: { mes: 'I am back' } }],
    };
    const hb = buildHeartbeatPrompt(ctx).user;
    assert.match(hb, /\[u1\] ask about the scar/);
    assert.match(hb, /\[d_old\]/);
    assert.match(hb, /30 h of silence between "goodnight" and "I am back"/);
    assert.match(hb, /revisit_id/);
    const dp = buildDiaryPrompt(ctx, 'rethink the letter', ctx.revisitCandidates[0]).user;
    assert.match(dp, /EARLIER ENTRY YOU ARE RETURNING TO/);
    assert.match(dp, /he lied about the letter/);
    assert.ok(!buildDiaryPrompt(ctx, 'x').user.includes('RETURNING TO'));
    assert.match(buildIdlePrompt(ctx).user, /\[u1\] ask about the scar/);
});

test('injection: time context appears only for a real return; unsaid is soft; budget respected', () => {
    const none = buildInjection({ charName: 'Alice', userName: 'Bob', memories: [], maxChars: 800 });
    assert.equal(none, '');
    const out = buildInjection({
        charName: 'Alice', userName: 'Bob', timeGap: { gapMs: 3 * DAY, now: T }, unsaid: [{ text: 'ask about the scar' }], memories: [], maxChars: 900,
    });
    assert.match(out, /Time context: it is afternoon/);
    assert.match(out, /Bob has just come back after 3 days away/);
    assert.match(out, /never forced/);
    assert.match(out, /ask about the scar/);
    assert.ok(out.length <= 920);
});
