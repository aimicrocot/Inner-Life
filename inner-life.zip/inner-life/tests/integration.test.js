// Integration smoke tests: the SillyTavern-facing modules run in jsdom against a fake SillyTavern context.
import test from 'node:test';
import assert from 'node:assert/strict';
import { JSDOM } from 'jsdom';

const dom = new JSDOM('<!doctype html><body></body>');
globalThis.window = dom.window;
globalThis.document = dom.window.document;

// ---- fake server: in-memory user files ----
const files = new Map();
globalThis.fetch = async (url, opts = {}) => {
    const u = String(url);
    if (u.startsWith('/user/files/')) {
        const name = u.slice('/user/files/'.length).split('?')[0];
        return files.has(name) ? new Response(files.get(name), { status: 200 }) : new Response('', { status: 404 });
    }
    if (u === '/api/files/upload') {
        const b = JSON.parse(opts.body);
        files.set(b.name, Buffer.from(b.data, 'base64').toString('utf8'));
        return new Response(JSON.stringify({ path: `user/files/${b.name}` }), { status: 200 });
    }
    if (u === '/api/files/delete') {
        const b = JSON.parse(opts.body);
        files.delete(b.path.replace('user/files/', ''));
        return new Response('{}', { status: 200 });
    }
    return new Response('', { status: 500 });
};

// ---- fake SillyTavern context ----
const extPrompts = {};
const processed = [];
const emitted = [], rendered = [];
let saves = 0;
const SENT_AT = '2026-06-01T10:00:00.000Z';
const fakeChat = [
    { name: 'Bob', is_user: true, mes: 'I am afraid of thunderstorms.', send_date: '2026-06-01T09:00:00.000Z' },
    { name: 'Alice', is_user: false, mes: 'I will stay with you.', send_date: '2026-06-01T09:30:00.000Z' },
    { name: 'Bob', is_user: true, mes: 'There is a thunderstorm tonight', send_date: SENT_AT },
];
const fakeCtx = {
    groupId: null, characterId: 0, chatId: 'chat-1', name1: 'Bob', name2: 'Alice', chat: fakeChat,
    characters: [{ name: 'Alice', avatar: 'Alice.png', data: { description: 'A calm pilot' } }],
    getRequestHeaders: () => ({ 'Content-Type': 'application/json' }),
    setExtensionPrompt: (k, v, type, depth, scan, role) => { extPrompts[k] = { v, type, depth, role }; },
    ChatCompletionService: { processRequest: async (payload) => { processed.push(payload); return { content: 'OK' }; } },
    POPUP_TYPE: { TEXT: 1, CONFIRM: 2 }, POPUP_RESULT: { AFFIRMATIVE: 1 },
    callGenericPopup: (content) => { fakeCtx.lastPopup = content; return new Promise(() => {}); },
    extensionSettings: {},
    event_types: { MESSAGE_RECEIVED: 'message_received', CHARACTER_MESSAGE_RENDERED: 'character_message_rendered' },
    eventSource: { emit: async (e, ...a) => { emitted.push([e, ...a]); } },
    addOneMessage: (m) => { rendered.push(m); },
    saveChat: async () => { saves++; },
};
globalThis.SillyTavern = { getContext: () => fakeCtx };
globalThis.toastr = { info() {}, success() {}, warning() {}, error() {} };

const { loadChar, saveChar, flushAll, deleteCharData } = await import('../src/storage.js');
const { addDiaryEntry, addMemory } = await import('../src/store.js');
const { callModel, normalizeBaseUrl, setSessionKey, testProfile } = await import('../src/llm.js');
const { computeInjection, installInterceptor, INJECTION_KEY, INTERCEPTOR_NAME } = await import('../src/injector.js');
const { mergeSettings, newProfile, getCharSettings } = await import('../src/settings.js');
const { openPanel } = await import('../src/ui.js');
const { HeartbeatEngine } = await import('../src/heartbeat.js');
const { getSnapshot, insertCharacterMessage, isUserComposing } = await import('../src/host.js');
const { createGoal } = await import('../src/goals.js');
const { addUnsaid } = await import('../src/unsaid.js');

const wait = (ms = 20) => new Promise(r => setTimeout(r, ms));

test('storage: round-trips unicode data through the user-files API and survives a "restart"', async () => {
    const d = await loadChar('Alice.png', 'Alice');
    addDiaryEntry(d, { text: 'Сегодня он признался в страхе перед грозой 🌩', chatId: 'chat-1' });
    addMemory(d, { text: 'Bob боится грозы с детства', confidence: 'confirmed', importance: 4 });
    saveChar(d);
    await flushAll();
    const names = [...files.keys()];
    assert.equal(names.length, 1);
    assert.match(names[0], /^inner-life-alice_[a-z0-9]+\.json$/);
    const onDisk = JSON.parse(files.get(names[0]));
    assert.equal(onDisk.diary[0].text, 'Сегодня он признался в страхе перед грозой 🌩');
    assert.equal(onDisk.memories.length, 1);
});

test('storage: a corrupt file is never overwritten', async () => {
    files.set('inner-life-broken_x.json', '{not json');
    const { fileNameForCharacter } = await import('../src/util.js');
    files.set(fileNameForCharacter('Broken.png'), '{not json');
    await assert.rejects(() => loadChar('Broken.png', 'Broken'), /повреждён/);
    assert.equal(files.get(fileNameForCharacter('Broken.png')), '{not json');
});

test('llm: OpenAI-compatible profile goes through ST backend with proxy url + key, normalized', async () => {
    assert.equal(normalizeBaseUrl('https://p.example.com/v1/chat/completions/'), 'https://p.example.com/v1');
    assert.equal(normalizeBaseUrl('ftp://x'), '');
    const p = { ...newProfile('openai'), baseUrl: 'https://p.example.com/v1/', apiKey: 'KEY-123456', model: 'cheap-model', temperature: 0.3 };
    const r = await callModel(p, { system: 's', user: 'u', maxTokens: 200 });
    assert.equal(r.text, 'OK');
    const sent = processed.at(-1);
    assert.equal(sent.reverse_proxy, 'https://p.example.com/v1');
    assert.equal(sent.proxy_password, 'KEY-123456');
    assert.equal(sent.chat_completion_source, 'openai');
    assert.equal(sent.model, 'cheap-model');
    assert.equal(sent.stream, false);
    assert.equal(sent.max_tokens, 200);
});

test('llm: session-only keys are used but never persisted in the profile', async () => {
    const p = { ...newProfile('openai'), baseUrl: 'https://p.example.com/v1', persistKey: false, apiKey: '', model: 'm' };
    setSessionKey(p.id, 'SESSION-KEY-999');
    await callModel(p, { system: 's', user: 'u', maxTokens: 50 });
    assert.equal(processed.at(-1).proxy_password, 'SESSION-KEY-999');
    assert.equal(p.apiKey, '');
});

test('llm: validation errors are reported (no URL / no model), and test never throws or leaks the key', async () => {
    const bad = { ...newProfile('openai'), baseUrl: '', model: 'm', apiKey: 'SECRET-KEY-ABC' };
    await assert.rejects(() => callModel(bad, { system: 's', user: 'u' }), /Base URL/);
    const t = await testProfile({ ...bad, baseUrl: 'https://x.example/v1' , model: '' }, ['SECRET-KEY-ABC']);
    assert.equal(t.ok, false);
    assert.ok(!t.error.includes('SECRET-KEY-ABC'));
    const ok = await testProfile({ ...newProfile('openai'), baseUrl: 'https://x.example/v1', model: 'm', apiKey: 'k' });
    assert.equal(ok.ok, true);
});

test('llm: aborting from outside (chat changed) stops the call with AbortError', async () => {
    const orig = fakeCtx.ChatCompletionService.processRequest;
    fakeCtx.ChatCompletionService.processRequest = (_p, _o, _e, signal) => new Promise((_, rej) => signal.addEventListener('abort', () => rej(new Error('aborted'))));
    const p = { ...newProfile('openai'), baseUrl: 'https://x.example/v1', model: 'm', retries: 0 };
    const ctrl = new AbortController();
    setTimeout(() => ctrl.abort(), 30);
    await assert.rejects(() => callModel(p, { system: 's', user: 'u', signal: ctrl.signal }), (e) => e.name === 'AbortError');
    fakeCtx.ChatCompletionService.processRequest = orig;
});

test('injection: relevant memory is selected, interceptor sets the extension prompt, quiet type clears it', async () => {
    const d = await loadChar('Alice.png', 'Alice');
    addMemory(d, { text: 'Bob likes jazz and old vinyl records', importance: 2 });
    d.state.mood = 'protective';
    const settings = mergeSettings({ enabled: true, characters: { 'Alice.png': { enabled: true } } });
    const text = computeInjection(settings);
    assert.match(text, /^\[Private continuity notes for Alice/);
    assert.match(text, /боится грозы/);
    assert.match(text, /protective/);

    installInterceptor(() => settings);
    await globalThis[INTERCEPTOR_NAME]([], 4096, () => {}, 'normal');
    assert.match(extPrompts[INJECTION_KEY].v, /боится грозы/);
    assert.equal(extPrompts[INJECTION_KEY].type, 1); // IN_CHAT
    assert.equal(extPrompts[INJECTION_KEY].depth, settings.injection.depth);
    await globalThis[INTERCEPTOR_NAME]([], 4096, () => {}, 'quiet');
    assert.equal(extPrompts[INJECTION_KEY].v, '');

    settings.enabled = false;
    await globalThis[INTERCEPTOR_NAME]([], 4096, () => {}, 'normal');
    assert.equal(extPrompts[INJECTION_KEY].v, '');
});

test('host snapshot: skips system messages and refuses group chats', () => {
    fakeChat.push({ name: 'sys', is_user: false, is_system: true, mes: 'hidden' });
    const snap = getSnapshot();
    assert.equal(snap.messages.length, 3);
    assert.equal(snap.avatar, 'Alice.png');
    fakeChat.pop();
    fakeCtx.groupId = 'g1';
    assert.equal(getSnapshot(), null);
    fakeCtx.groupId = null;
});

test('host snapshot: exposes last message time, initiative flags and "user is typing"', () => {
    const snap = getSnapshot();
    assert.equal(snap.lastMessageAt, Date.parse(SENT_AT));
    assert.equal(snap.composing, false);
    assert.ok(snap.messages.every(m => m.initiative === false));
    const ta = document.createElement('textarea'); ta.id = 'send_textarea'; document.body.append(ta);
    ta.value = '   ';
    assert.equal(isUserComposing(), false);
    ta.value = 'half-written thought';
    assert.equal(getSnapshot().composing, true);
    ta.remove();
});

test('initiative message is inserted like /sendas: pushed, events fired in order, rendered, saved, flagged', async () => {
    const before = fakeChat.length;
    const id = await insertCharacterMessage({ charName: 'Alice', text: 'Hey, are you still awake?', reason: 'storm follow-up' });
    assert.equal(id, before);
    const m = fakeChat.at(-1);
    assert.equal(m.name, 'Alice');
    assert.equal(m.is_user, false);
    assert.equal(m.is_system, false);
    assert.equal(m.mes, 'Hey, are you still awake?');
    assert.deepEqual(m.swipes, ['Hey, are you still awake?']);
    assert.equal(m.extra.inner_life.initiative, true);
    assert.ok(!Number.isNaN(Date.parse(m.send_date)));
    assert.deepEqual(emitted.map(e => e[0]).slice(-2), ['message_received', 'character_message_rendered']);
    assert.equal(rendered.at(-1), m);
    assert.ok(saves >= 1);
    // it is recognised as our own initiative later (anti-spam relies on this)
    const snap = getSnapshot();
    assert.equal(snap.messages.at(-1).initiative, true);
    fakeChat.pop();
});

test('injection: active goals appear as soft wants; paused/closed goals do not', async () => {
    const d = await loadChar('Alice.png', 'Alice');
    const settings = mergeSettings({ enabled: true, characters: { 'Alice.png': { enabled: true } } });
    createGoal(d, { kind: 'long', text: 'Understand why he fears thunderstorms', reason: 'r', criteria: 'he explains' }, Date.now(), { maxActive: 5, maxNewPerDay: 9 });
    const g2 = createGoal(d, { kind: 'long', text: 'Plan a surprise for his birthday party', reason: 'r', criteria: 'it happens' }, Date.now(), { maxActive: 5, maxNewPerDay: 9 }).goal;
    g2.status = 'paused';
    const text = computeInjection(settings);
    assert.match(text, /fears thunderstorms/);
    assert.ok(!text.includes('birthday'));
    getCharSettings(settings, 'Alice.png').goals = false;
    assert.ok(!computeInjection(settings).includes('fears thunderstorms'));
    d.goals.length = 0;
});

test('injection: time context only right after a real return; switchable; unsaid thoughts are soft hints', async () => {
    const d = await loadChar('Alice.png', 'Alice');
    const settings = mergeSettings({ enabled: true, characters: { 'Alice.png': { enabled: true } } });
    // Alice spoke 4 days ago, Bob has just written
    fakeChat.push({ name: 'Alice', is_user: false, mes: 'Sleep well.', send_date: '2026-05-28T22:00:00.000Z' });
    fakeChat.push({ name: 'Bob', is_user: true, mes: 'I am back!', send_date: '2026-06-01T20:00:00.000Z' });
    const withGap = computeInjection(settings);
    assert.match(withGap, /Time context/);
    assert.match(withGap, /Bob has just come back after 4 days away/);

    settings.awareness.timeGaps = false;
    assert.ok(!computeInjection(settings).includes('Time context'));
    settings.awareness.timeGaps = true;

    // the conversation moved on: the return is old news
    fakeChat.push({ name: 'Alice', is_user: false, mes: 'Welcome back!', send_date: '2026-06-01T20:01:00.000Z' });
    fakeChat.push({ name: 'Alice', is_user: false, mes: 'Tell me everything.', send_date: '2026-06-01T20:02:00.000Z' });
    assert.ok(!computeInjection(settings).includes('Time context'));
    fakeChat.length = 3;

    addUnsaid(d, { text: 'I want to ask why he never talks about his father', why: 'tact' }, Date.now(), { maxHeld: 5 });
    const t = computeInjection(settings);
    assert.match(t, /holding back/);
    assert.match(t, /why he never talks about his father/);
    assert.ok(!t.includes('tact'), 'the private reason is not sent to the main model');
    getCharSettings(settings, 'Alice.png').unsaid = false;
    assert.ok(!computeInjection(settings).includes('holding back'));
    d.unsaid.length = 0;
});

test('UI: every tab renders; hostile model text is shown as text, never as HTML', async () => {
    const settings = mergeSettings({ enabled: true, characters: { 'Alice.png': { enabled: true } } });
    const data = await loadChar('Alice.png', 'Alice');
    addDiaryEntry(data, { text: 'Evil <img src=x onerror=alert(1)> <script>alert(2)</script> entry text', tags: ['<b>x</b>'] });
    const oldE = addDiaryEntry(data, { text: 'OLD-ENTRY-TEXT: I suspect he lied about the letter.' }, Date.now() - 86400000);
    addDiaryEntry(data, { text: 'I was wrong about the letter, he only forgot.', revisit: { of: oldE.id, stance: 'withdrawn' } });
    addUnsaid(data, { text: 'UNSAID-TEXT about the scar on his hand', why: 'SECRET-WHY-TEXT' }, Date.now(), { maxHeld: 5 });
    createGoal(data, { kind: 'long', text: 'Goal <img src=y onerror=alert(3)> about storms', reason: 'SECRET-REASON-TEXT', criteria: 'CRITERIA-TEXT-HERE' }, Date.now(), { maxActive: 5, maxNewPerDay: 9 });
    const engine = new HeartbeatEngine({ now: Date.now, getSettings: () => settings, saveSettings() {}, getSnapshot, loadChar, saveChar, callModel: async () => ({ text: '' }) });
    const app = {
        getSettings: () => settings, saveSettings() {}, engine,
        currentCharacter: () => ({ avatar: 'Alice.png', name: 'Alice', chatId: 'chat-1' }),
        loadChar, saveChar, deleteCharData, exportJson: JSON.stringify, computeInjection: () => 'preview text',
    };
    settings.models.profiles.push({ ...newProfile('openai'), id: 'p-ui', name: 'Мой прокси' });
    openPanel(app);
    await wait();
    const root = fakeCtx.lastPopup;
    assert.ok(root, 'popup content created');
    const tabs = [...root.querySelectorAll('.il-tab')];
    assert.equal(tabs.length, 8);
    const seen = [];
    for (const tab of tabs) {
        tab.dispatchEvent(new dom.window.Event('click'));
        await wait();
        const body = root.querySelector('.il-body');
        assert.ok(body.textContent.length > 20, `tab "${tab.textContent}" rendered`);
        assert.ok(!body.textContent.includes('undefined'), `tab "${tab.textContent}" has no 'undefined'`);
        assert.ok(!body.textContent.includes('[object Object]'), `tab "${tab.textContent}" has no '[object Object]'`);
        seen.push(tab.textContent);
        if (tab.textContent === 'Дневник') {
            assert.match(body.textContent, /отказывается от прежнего вывода запись от .*OLD-ENTRY-TEXT/);
            assert.match(body.textContent, /Позже пересмотрено \(1\)/);
            assert.equal(root.querySelectorAll('img, script').length, 0);
            assert.match(body.textContent, /<img src=x onerror=alert\(1\)>/);
        }
        if (tab.textContent === 'Модели') assert.match(body.textContent, /Мой прокси/);
        if (tab.textContent === 'Цели') {
            assert.equal(root.querySelectorAll('img, script').length, 0);
            assert.match(body.textContent, /SECRET-REASON-TEXT/);
            assert.match(body.textContent, /CRITERIA-TEXT-HERE/);
            assert.match(body.textContent, /UNSAID-TEXT about the scar/);
            assert.match(body.textContent, /SECRET-WHY-TEXT/);
        }
        if (tab.textContent === 'Инициатива') assert.match(body.textContent, /Режим инициативы/);
    }
    // goal transparency: "summary" hides reasons/criteria, "hidden" hides the list entirely
    const goalsTab = tabs.find(t => t.textContent === 'Цели');
    for (const [vis, expectText, unsaidShown] of [['summary', /about storms/, true], ['hidden', /скрыты/, false]]) {
        settings.goals.visibility = vis;
        goalsTab.dispatchEvent(new dom.window.Event('click'));
        await wait();
        const t = root.querySelector('.il-body').textContent;
        assert.match(t, expectText);
        assert.ok(!t.includes('SECRET-REASON-TEXT') && !t.includes('CRITERIA-TEXT-HERE') && !t.includes('SECRET-WHY-TEXT'), `visibility ${vis} must hide reasons`);
        assert.equal(t.includes('UNSAID-TEXT about the scar'), unsaidShown, `visibility ${vis}: unsaid text shown = ${unsaidShown}`);
    }
    assert.deepEqual(seen, ['Обзор', 'Дневник', 'Память', 'Цели', 'Инициатива', 'Heartbeat', 'Модели', 'Настройки']);
});

test('storage: delete removes the file and the cache entry', async () => {
    await deleteCharData('Alice.png');
    const { fileNameForCharacter } = await import('../src/util.js');
    assert.equal(files.has(fileNameForCharacter('Alice.png')), false);
});
