import test from 'node:test';
import assert from 'node:assert/strict';
import { HeartbeatEngine } from '../src/heartbeat.js';
import { createGoal } from '../src/goals.js';
import { addDiaryEntry } from '../src/store.js';
import { addUnsaid, heldUnsaid } from '../src/unsaid.js';
import { mergeSettings, newProfile } from '../src/settings.js';
import { emptyCharData, migrateCharData } from '../src/store.js';

const T0 = new Date(2026, 5, 1, 12, 0).getTime();
const H = 3600000;

function kindOf(system) {
    if (system.includes('personal goals')) return 'goals';
    if (system.includes('Write the next chat message')) return 'compose';
    if (system.includes('has been quiet')) return 'idle';
    if (system.includes('diary entry')) return 'diary';
    if (system.includes('long-term memory')) return 'memory';
    return 'heartbeat';
}

function setup({ replies = {}, init = {}, charSettings = {}, messages = 6, silenceH = 3, patch = {} } = {}) {
    const settings = mergeSettings({
        enabled: true,
        initiative: { mode: 'moderate', ...init },
        characters: { 'A.png': { enabled: true, initiative: true, ...charSettings } },
        ...patch,
    });
    settings.heartbeat.debounceSec = 0;
    let now = T0;
    const stored = {};
    const calls = [];
    const sent = [];
    const env = {
        chatId: 'chat1', composing: false, generating: false,
        lastMessageAt: T0 - silenceH * H,
        msgs: Array.from({ length: messages }, (_, i) => ({ idx: i, name: i % 2 ? 'Alice' : 'Bob', is_user: !(i % 2), mes: `message ${i}`, initiative: false })),
    };
    const deps = {
        now: () => now,
        getSettings: () => settings,
        saveSettings: () => {},
        getSnapshot: () => ({ chatId: env.chatId, avatar: 'A.png', charName: 'Alice', userName: 'Bob', card: { description: 'A thoughtful pilot' }, generating: env.generating, composing: env.composing, lastMessageAt: env.lastMessageAt, messages: [...env.msgs] }),
        loadChar: async (avatar, name) => (stored[avatar] ||= migrateCharData(emptyCharData(avatar, name, T0), avatar, name, T0)),
        saveChar: () => {},
        callModel: async (profile, req) => {
            const kind = kindOf(req.system);
            calls.push({ kind, profile: profile.id });
            const r = replies[kind];
            if (r instanceof Error) throw r;
            if (r === undefined) throw new Error(`no scripted reply for ${kind}`);
            return { text: typeof r === 'function' ? r(req) : r };
        },
        sendMessage: async ({ text, reason }) => { sent.push({ text, reason }); env.msgs.push({ idx: env.msgs.length, name: 'Alice', is_user: false, mes: text, initiative: true }); },
        redact: (t) => t,
    };
    const engine = new HeartbeatEngine(deps);
    const data = () => (stored['A.png'] ||= migrateCharData(emptyCharData('A.png', 'Alice', T0), 'A.png', 'Alice', T0));
    const addGoal = () => createGoal(data(), { kind: 'long', text: 'Find out why he fears thunderstorms', reason: 'he flinched', criteria: 'he tells me', priority: 4 }, T0, { maxActive: 5, maxNewPerDay: 9 }).goal;
    return { engine, settings, stored, calls, sent, env, data, addGoal, advance: (ms) => { now += ms; }, setNow: (t) => { now = t; } };
}

const IDLE_YES = JSON.stringify({ reach_out: true, reason: 'wants to follow up on the storm fear', topic: 'thunderstorms', goal_id: null });
const IDLE_NO = JSON.stringify({ reach_out: false, reason: '', topic: '', goal_id: null });
const HB_GOALS = JSON.stringify({ mood: 'curious', diary: false, remember: false, goals: true, working_note: 'wants to ask about storms' });
const goalOps = JSON.stringify({ ops: [{ op: 'create', kind: 'long', text: 'Understand why Bob fears thunderstorms', reason: 'he mentioned it twice', criteria: 'Bob explains the origin himself', priority: 4 }] });

// ------------------------------------------------------------ goals through the cycle

test('cycle: heartbeat flags goals -> goals model (own profile) creates a goal with reason and criteria', async () => {
    const h = setup({ replies: { heartbeat: HB_GOALS, goals: goalOps } });
    const cheap = newProfile('openai'); cheap.id = 'goalsmodel';
    h.settings.models.profiles.push(cheap);
    h.settings.models.assign.goals = 'goalsmodel';
    await h.engine.tick(); // baseline
    for (let i = 6; i < 11; i++) h.env.msgs.push({ idx: i, name: 'Bob', is_user: true, mes: `m${i}`, initiative: false });
    h.advance(11 * 60000);
    const r = await h.engine.tick();
    assert.equal(r.status, 'ok');
    assert.deepEqual(h.calls.map(c => [c.kind, c.profile]), [['heartbeat', 'current'], ['goals', 'goalsmodel']]);
    const g = h.data().goals[0];
    assert.equal(g.status, 'active');
    assert.match(g.criteria, /explains the origin/);
    assert.match(r.summary, /цели \+1/);
});

test('cycle: no goals call unless the cheap decision asks for it, and not when goals are disabled for the character', async () => {
    const no = setup({ replies: { heartbeat: JSON.stringify({ mood: 'calm', diary: false, remember: false, goals: false }) } });
    await no.engine.tick();
    for (let i = 6; i < 11; i++) no.env.msgs.push({ idx: i, name: 'Bob', is_user: true, mes: 'x', initiative: false });
    no.advance(11 * 60000);
    await no.engine.tick();
    assert.deepEqual(no.calls.map(c => c.kind), ['heartbeat']);

    const off = setup({ replies: { heartbeat: HB_GOALS, goals: goalOps }, charSettings: { goals: false } });
    await off.engine.tick();
    for (let i = 6; i < 11; i++) off.env.msgs.push({ idx: i, name: 'Bob', is_user: true, mes: 'x', initiative: false });
    off.advance(11 * 60000);
    await off.engine.tick();
    assert.ok(!off.calls.some(c => c.kind === 'goals'));
    assert.equal(off.data().goals.length, 0);
});

test('cycle: a goal is completed only when the model gives evidence; duplicates are not recreated', async () => {
    const h = setup({ replies: { heartbeat: HB_GOALS, goals: goalOps } });
    await h.engine.tick();
    const push = (from) => { for (let i = from; i < from + 5; i++) h.env.msgs.push({ idx: i, name: 'Bob', is_user: true, mes: `m${i}`, initiative: false }); };
    push(6); h.advance(11 * 60000); await h.engine.tick();
    const g = h.data().goals[0];
    // same proposal again -> duplicate, nothing new
    push(11); h.advance(11 * 60000); await h.engine.tick();
    assert.equal(h.data().goals.length, 1);
    // completion without evidence -> rejected
    h.engine.deps.callModel = async (p, req) => ({ text: kindOf(req.system) === 'goals' ? JSON.stringify({ ops: [{ op: 'complete', id: g.id }] }) : HB_GOALS });
    push(16); h.advance(11 * 60000); await h.engine.tick();
    assert.equal(g.status, 'active');
    h.engine.deps.callModel = async (p, req) => ({ text: kindOf(req.system) === 'goals' ? JSON.stringify({ ops: [{ op: 'complete', id: g.id, evidence: 'Bob told the story about the barn fire' }] }) : HB_GOALS });
    push(21); h.advance(11 * 60000); const r = await h.engine.tick();
    assert.equal(g.status, 'done');
    assert.match(r.summary, /достигнуто 1/);
});

// ------------------------------------------------------------ initiative

test('initiative end-to-end: silence + reason -> cheap decision -> compose on its own model -> message sent', async () => {
    const h = setup({ replies: { idle: IDLE_YES, compose: 'Alice: "Hey… I kept thinking about the storm last night. Are you okay?"' } });
    const prof = newProfile('openai'); prof.id = 'voice';
    h.settings.models.profiles.push(prof);
    h.settings.models.assign.initiative = 'voice';
    h.addGoal();
    await h.engine.tick(); // baseline set, then idle path is evaluated in the same tick
    const calls = h.calls.map(c => [c.kind, c.profile]);
    assert.deepEqual(calls, [['idle', 'current'], ['compose', 'voice']]);
    assert.equal(h.sent.length, 1);
    assert.equal(h.sent[0].text, 'Hey… I kept thinking about the storm last night. Are you okay?');
    assert.match(h.sent[0].reason, /follow up/);
    const st = h.data().state.initiative;
    assert.equal(st.sent, 1);
    assert.equal(st.idleChecks, 1);
    assert.ok(h.data().state.log.some(l => l.kind === 'initiative' && l.ok));
});

test('initiative: no reason to write (no goals, no working note) -> zero model calls', async () => {
    const h = setup({ replies: { idle: IDLE_YES, compose: 'hi' } });
    await h.engine.tick();
    assert.equal(h.calls.length, 0);
    assert.equal(h.engine.getStatus().lastInitiative, 'no-reason-to-write');
});

test('initiative: every protective gate blocks BEFORE any model call', async () => {
    const cases = [
        ['mode off', { init: { mode: 'off' } }, null],
        ['character opt-out', { charSettings: { initiative: false } }, null],
        ['live conversation', { silenceH: 0.1 }, null],
        ['user typing', {}, (h) => { h.env.composing = true; }],
        ['main generation', {}, (h) => { h.env.generating = true; }],
        ['quiet hours', { init: { quietStart: 11, quietEnd: 14 } }, null],
        ['unanswered initiative', {}, (h) => { h.env.msgs.push({ idx: 99, name: 'Alice', is_user: false, mes: 'ping', initiative: true }); }],
    ];
    for (const [name, opts, mutate] of cases) {
        const h = setup({ replies: { idle: IDLE_YES, compose: 'hi' }, ...opts });
        h.addGoal();
        mutate?.(h);
        await h.engine.tick();
        assert.equal(h.calls.length, 0, `${name}: model must not be called`);
        assert.equal(h.sent.length, 0, `${name}: nothing sent`);
    }
});

test('initiative: model may decline; the check still counts toward the daily cap, bounding cost', async () => {
    const h = setup({ replies: { idle: IDLE_NO }, init: { maxIdleChecksPerDay: 2, idleCheckMin: 5 } });
    h.addGoal();
    await h.engine.tick();
    h.advance(10 * 60000); await h.engine.tick();
    h.advance(10 * 60000); await h.engine.tick(); // third check: capped
    assert.equal(h.calls.filter(c => c.kind === 'idle').length, 2);
    assert.equal(h.sent.length, 0);
});

test('initiative: rate limits - one per gap, and never twice in a row without a user reply', async () => {
    const h = setup({ replies: { idle: IDLE_YES, compose: 'Thinking of you.' }, init: { idleCheckMin: 5 } });
    h.addGoal();
    await h.engine.tick();
    assert.equal(h.sent.length, 1);
    h.advance(6 * H); await h.engine.tick(); // gap (90 min) passed, but the first message is unanswered
    assert.equal(h.sent.length, 1);
    h.env.msgs.push({ idx: h.env.msgs.length, name: 'Bob', is_user: true, mes: 'hi!', initiative: false });
    h.env.lastMessageAt = h.engine.deps.now();
    h.advance(3 * H); h.env.lastMessageAt = h.engine.deps.now() - 3 * H;
    await h.engine.tick();
    assert.equal(h.sent.length, 2);
});

test('initiative: if the user replies while the message is being composed, it is discarded', async () => {
    const h = setup({ replies: { idle: IDLE_YES, compose: () => { h.env.msgs.push({ idx: h.env.msgs.length, name: 'Bob', is_user: true, mes: 'I am back!', initiative: false }); return 'Hello there'; } } });
    h.addGoal();
    await h.engine.tick();
    assert.equal(h.sent.length, 0);
    assert.ok(h.data().state.log.some(l => /user-replied/.test(l.summary)));
});

test('initiative: chat switched during composition -> nothing is sent', async () => {
    const h = setup({ replies: { idle: IDLE_YES, compose: () => { h.env.chatId = 'other'; return 'Hello there'; } } });
    h.addGoal();
    await h.engine.tick();
    assert.equal(h.sent.length, 0);
});

test('initiative: manual test skips the decision and the silence rule, but still respects typing', async () => {
    const h = setup({ replies: { compose: 'Manual hello!' }, silenceH: 0.05 });
    const r = await h.engine.runInitiative({ manual: true });
    assert.equal(r.sent, true);
    assert.deepEqual(h.calls.map(c => c.kind), ['compose']);
    const t = setup({ replies: { compose: 'x' } });
    t.env.composing = true;
    assert.match((await t.engine.runInitiative({ manual: true })).reason, /user-is-typing/);
    assert.equal(t.calls.length, 0);
});

test('initiative: budget kill switch blocks the decision call; API error uses backoff and redaction', async () => {
    const h = setup({ replies: { idle: IDLE_YES, compose: 'hi' } });
    h.addGoal();
    h.settings.limits.backgroundCallsEnabled = false;
    await h.engine.tick();
    assert.equal(h.calls.length, 0);
    assert.equal(h.sent.length, 0);

    const e = setup({ replies: { idle: new Error('boom 503') } });
    e.addGoal();
    const r = await e.engine.tick();
    assert.equal(r.status, 'error');
    assert.equal((await e.engine.tick()).reason, 'backoff');
});

test('initiative: goal progress is noted when a message advances a goal', async () => {
    const h = setup({ replies: { compose: 'ok' } });
    const g = h.addGoal();
    h.engine.deps.callModel = async (p, req) => ({ text: kindOf(req.system) === 'idle' ? JSON.stringify({ reach_out: true, reason: 'advance goal', topic: 't', goal_id: g.id }) : 'Hi, can I ask you something about storms?' });
    await h.engine.tick();
    assert.equal(h.sent.length, 1);
    assert.equal(g.history.at(-1).event, 'progress');
});


// ------------------------------------------------------------ revisiting the diary, unsaid thoughts, time gaps

const DAY = 86400000;
const pushMsgs = (h, from, n, mes = 'x', ts = 0) => { for (let i = from; i < from + n; i++) h.env.msgs.push({ idx: i, name: 'Bob', is_user: true, mes, initiative: false, ts }); };

test('revisit: character returns to an old entry; the original stays untouched and is only marked', async () => {
    let oldEntry;
    let diaryPrompt = '';
    const h = setup({ replies: {
        heartbeat: () => JSON.stringify({ mood: 'ashamed', diary: false, revisit_id: oldEntry.id, remember: false }),
        diary: (req) => { diaryPrompt = req.user; return JSON.stringify({ text: 'I wrote that he lied about the letter. I was wrong: he simply forgot.', mood: 'ashamed', stance: 'withdrawn' }); },
    } });
    await h.engine.tick();
    oldEntry = addDiaryEntry(h.data(), { text: 'I think he lied to me about the letter from his father.' }, T0 - 5 * DAY);
    const originalText = oldEntry.text;
    pushMsgs(h, 6, 5, 'I finally found the letter, I had forgotten it');
    h.advance(11 * 60000);
    const r = await h.engine.tick();
    assert.equal(r.status, 'ok');
    assert.match(r.summary, /вернулся к прошлой записи/);
    const d = h.data();
    assert.equal(d.diary.length, 2);
    assert.equal(d.diary[1].revisit.of, oldEntry.id);
    assert.equal(d.diary[1].revisit.stance, 'withdrawn');
    assert.equal(oldEntry.text, originalText);
    assert.deepEqual(oldEntry.revisedBy, [d.diary[1].id]);
    assert.match(diaryPrompt, /EARLIER ENTRY YOU ARE RETURNING TO/);
    assert.match(diaryPrompt, /he lied to me about the letter/);
});

test('revisit: an unknown id from the model changes nothing and does not force a diary entry', async () => {
    const h = setup({ replies: { heartbeat: JSON.stringify({ mood: 'm', diary: false, revisit_id: 'd_ghost' }) } });
    await h.engine.tick();
    pushMsgs(h, 6, 5);
    h.advance(11 * 60000);
    await h.engine.tick();
    assert.deepEqual(h.calls.map(c => c.kind), ['heartbeat']);
    assert.equal(h.data().diary.length, 0);
});

test('unsaid: a held-back thought is stored from the decision (no extra model call), then resolved when said', async () => {
    let step = 0, itemId = null, secondPrompt = '';
    const h = setup({ replies: { heartbeat: (req) => {
        step++;
        if (step === 1) return JSON.stringify({ mood: 'shy', unsaid: { text: 'I want to ask why he never speaks about his father', why: 'afraid to hurt him' } });
        secondPrompt = req.user;
        return JSON.stringify({ mood: 'relieved', unsaid_resolved: [itemId] });
    } } });
    await h.engine.tick();
    pushMsgs(h, 6, 5); h.advance(11 * 60000);
    const r1 = await h.engine.tick();
    assert.deepEqual(h.calls.map(c => c.kind), ['heartbeat']);
    assert.match(r1.summary, /осталось недосказанное/);
    const item = heldUnsaid(h.data())[0];
    itemId = item.id;
    assert.equal(item.why, 'afraid to hurt him');
    pushMsgs(h, 11, 5); h.advance(11 * 60000);
    const r2 = await h.engine.tick();
    assert.match(secondPrompt, new RegExp(`\\[${itemId}\\] I want to ask why he never speaks`));
    assert.match(r2.summary, /высказано 1/);
    assert.equal(item.status, 'voiced');
});

test('unsaid: disabled per character -> nothing is stored', async () => {
    const h = setup({ replies: { heartbeat: JSON.stringify({ mood: 'm', unsaid: { text: 'I want to tell him something important' } }) }, charSettings: { unsaid: false } });
    await h.engine.tick();
    pushMsgs(h, 6, 5); h.advance(11 * 60000);
    await h.engine.tick();
    assert.equal(h.data().unsaid.length, 0);
});

test('unsaid: a held thought is a reason to reach out; when voiced on initiative it is marked as said', async () => {
    let composePrompt = '';
    const h = setup({ replies: { compose: 'placeholder' } });
    const u = addUnsaid(h.data(), { text: 'I never thanked him for staying with me during the storm', why: 'too proud' }, T0 - DAY, { maxHeld: 5 }).item;
    h.engine.deps.callModel = async (p, req) => {
        const k = kindOf(req.system);
        if (k === 'idle') return { text: JSON.stringify({ reach_out: true, reason: 'finally feels able to say it', topic: '', goal_id: null, unsaid_id: u.id }) };
        composePrompt = req.user;
        return { text: 'I never said it properly... thank you for staying with me that night.' };
    };
    await h.engine.tick();
    assert.equal(h.sent.length, 1);
    assert.match(composePrompt, /About: I never thanked him/);
    assert.equal(u.status, 'voiced');
    assert.match(u.note, /own initiative/);
});

test('time gaps: long silences in the processed stretch are shown to the models; switchable off', async () => {
    const run = async (timeGaps) => {
        let prompt = '';
        const h = setup({ replies: { heartbeat: (req) => { prompt = req.user; return JSON.stringify({ mood: 'm' }); } }, patch: { awareness: { timeGaps, gapMinHours: 6 } } });
        await h.engine.tick();
        h.env.msgs.forEach((m, i) => { m.ts = T0 - 100 * H + i * 60000; });
        pushMsgs(h, 6, 1, 'goodnight', T0 - 50 * H);
        pushMsgs(h, 7, 4, 'I am back after the trip!', T0 - 2 * H);
        h.advance(11 * 60000);
        await h.engine.tick();
        return prompt;
    };
    assert.match(await run(true), /LONG SILENCES IN THIS STRETCH/);
    assert.ok(!(await run(false)).includes('LONG SILENCES'));
});
