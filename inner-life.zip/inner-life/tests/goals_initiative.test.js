import test from 'node:test';
import assert from 'node:assert/strict';
import { applyGoalOps, createGoal, deleteGoal, expireStaleGoals, getActiveGoals, goalsForInjection, pruneClosedGoals, userEditGoal, userSetGoalStatus } from '../src/goals.js';
import { canReachOut, cleanInitiativeText, countTrailingUnanswered, idleCheckDue, initiativeLimits, recordIdleCheck, recordInitiativeSent, rollInitiativeState } from '../src/initiative.js';
import { buildGoalsPrompt, buildIdlePrompt, buildInjection, normalizeGoalOps, normalizeIdleResult } from '../src/prompts.js';
import { emptyCharData, emptyInitiativeState } from '../src/store.js';
import { mergeSettings } from '../src/settings.js';

const T = new Date(2026, 5, 1, 14, 0).getTime();
const DAY = 86400000;
const L = { maxActive: 5, maxNewPerDay: 3, chatId: 'c1' };
const fresh = () => emptyCharData('A.png', 'Alice', T);
const long = (text, extra = {}) => ({ kind: 'long', text, reason: 'because I care', criteria: 'he tells me himself', priority: 3, ...extra });

// ---------------- goals ----------------

test('goal creation requires text, completion criteria; stores reason, status, history', () => {
    const d = fresh();
    assert.equal(createGoal(d, { text: 'short' }, T, L).reason, 'text-too-short');
    assert.equal(createGoal(d, { text: 'Understand why he fears storms', reason: 'r' }, T, L).reason, 'no-completion-criteria');
    const r = createGoal(d, long('Understand why he fears thunderstorms'), T, L);
    assert.equal(r.action, 'created');
    assert.equal(r.goal.status, 'active');
    assert.equal(r.goal.chatId, 'c1');
    assert.equal(r.goal.history[0].event, 'created');
});

test('goal loop protection: no duplicates of open goals or of recently closed ones', () => {
    const d = fresh();
    const g = createGoal(d, long('Understand why he fears thunderstorms'), T, L).goal;
    assert.equal(createGoal(d, long('Understand why he is afraid of thunderstorms'), T, L).reason, 'duplicate-or-recently-closed');
    applyGoalOps(d, [{ op: 'complete', id: g.id, evidence: 'He explained the childhood story himself' }], T + 1000, L);
    assert.equal(g.status, 'done');
    assert.equal(createGoal(d, long('Understand why he fears thunderstorms'), T + 2000, L).reason, 'duplicate-or-recently-closed');
    // after the memory window it may legitimately come back
    assert.equal(createGoal(d, long('Understand why he fears thunderstorms'), T + 20 * DAY, L).action, 'created');
});

test('limits: active goals, long goals, steps per parent, creations per day', () => {
    const d = fresh();
    const names = ['alpha topic about sailing boats', 'bravo question regarding childhood home', 'charlie promise about visiting lighthouse', 'delta curiosity concerning music taste'];
    for (let i = 0; i < 3; i++) assert.equal(createGoal(d, long(names[i]), T, { ...L, maxNewPerDay: 99 }).action, 'created');
    assert.equal(createGoal(d, long(names[3]), T, { ...L, maxNewPerDay: 99 }).reason, 'too-many-long-goals');
    const parent = d.goals[0];
    for (let i = 0; i < 3; i++) assert.equal(createGoal(d, { kind: 'step', parent: parent.id, text: `step number ${i} zebra${i} quokka${i}`, criteria: 'it happened' }, T, { ...L, maxNewPerDay: 99, maxActive: 10 }).action, 'created');
    assert.equal(createGoal(d, { kind: 'step', parent: parent.id, text: 'another step xylophone walrus', criteria: 'it is done' }, T, { ...L, maxNewPerDay: 99, maxActive: 10 }).reason, 'too-many-steps');
    assert.equal(createGoal(d, { kind: 'step', parent: 'nope', text: 'orphan step giraffe lemur', criteria: 'it is done' }, T, { ...L, maxNewPerDay: 99, maxActive: 10 }).reason, 'step-without-active-parent');
    const d2 = fresh();
    createGoal(d2, long('first goal about volcano hiking'), T, { ...L, maxNewPerDay: 1 });
    assert.equal(createGoal(d2, long('second goal about ocean sailing trip'), T + 1000, { ...L, maxNewPerDay: 1 }).reason, 'daily-goal-creation-limit');
});

test('completion needs evidence; closing a long goal drops its open steps', () => {
    const d = fresh();
    const p = createGoal(d, long('Keep my promise to visit the lighthouse together'), T, L).goal;
    const st = createGoal(d, { kind: 'step', parent: p.id, text: 'Remind him about the lighthouse trip softly', criteria: 'he replies about it' }, T, L).goal;
    const r1 = applyGoalOps(d, [{ op: 'complete', id: p.id, evidence: '' }], T + 1, L);
    assert.deepEqual(r1.skipped, ['completion-without-evidence']);
    assert.equal(p.status, 'active');
    applyGoalOps(d, [{ op: 'complete', id: p.id, evidence: 'We went to the lighthouse in the story' }], T + 2, L);
    assert.equal(p.status, 'done');
    assert.equal(p.evidence.length, 1);
    assert.equal(st.status, 'dropped');
});

test('model cannot touch goals the user changed; user actions always win', () => {
    const d = fresh();
    const g = createGoal(d, long('Learn what makes him laugh the hardest'), T, L).goal;
    userSetGoalStatus(d, g.id, 'paused', T + 1);
    assert.equal(g.status, 'paused');
    assert.equal(g.locked, true);
    const r = applyGoalOps(d, [{ op: 'resume', id: g.id }, { op: 'drop', id: g.id, reason: 'x' }, { op: 'update', id: g.id, progress: 'p' }], T + 2, L);
    assert.deepEqual(r.skipped, ['goal-locked-by-user', 'goal-locked-by-user', 'goal-locked-by-user']);
    assert.equal(g.status, 'paused');
    userEditGoal(d, g.id, 'Learn what truly makes him laugh', T + 3);
    assert.equal(g.history.at(-1).by, 'user');
    assert.equal(deleteGoal(d, g.id), true);
});

test('at most 3 operations per cycle, unknown ids and ops are rejected safely', () => {
    const d = fresh();
    const ops = ['a topic about gardening', 'b topic about astronomy', 'c topic about cooking pasta', 'd topic about chess openings'].map(t => ({ op: 'create', ...long(`Explore ${t}`) }));
    const r = applyGoalOps(d, ops, T, { ...L, maxNewPerDay: 99 });
    assert.equal(r.created, 3);
    assert.equal(applyGoalOps(d, [{ op: 'complete', id: 'ghost', evidence: 'whatever happened' }, { op: 'explode' }], T, L).skipped.length, 2);
    assert.equal(applyGoalOps(d, 'garbage', T, L).created, 0);
});

test('stale active goals expire; closed goals are pruned; absence of goals is fine', () => {
    const d = fresh();
    createGoal(d, long('Understand the meaning of his tattoo'), T, L);
    assert.equal(expireStaleGoals(d, T + 5 * DAY, 14), 0);
    assert.equal(expireStaleGoals(d, T + 15 * DAY, 14), 1);
    assert.equal(d.goals[0].status, 'dropped');
    assert.equal(getActiveGoals(d).length, 0);
    for (let i = 0; i < 5; i++) { d.goals.push({ ...d.goals[0], id: `x${i}`, closedAt: T + i }); }
    assert.equal(pruneClosedGoals(d, 2), 4);
});

test('goalsForInjection orders by priority then recency and respects the limit', () => {
    const d = fresh();
    createGoal(d, long('low priority curiosity about ferries', { priority: 1 }), T, { ...L, maxNewPerDay: 9 });
    createGoal(d, long('high priority wish to repair the quarrel', { priority: 5 }), T + 1, { ...L, maxNewPerDay: 9 });
    const top = goalsForInjection(d, 1);
    assert.equal(top.length, 1);
    assert.match(top[0].text, /repair the quarrel/);
});

test('goal prompt validators', () => {
    assert.equal(normalizeGoalOps({ nope: 1 }), null);
    const ops = normalizeGoalOps({ ops: [{ op: 'CREATE', text: 'x', parent: 'null' }, { op: 'bogus' }, null, { op: 'drop', id: 'g1' }] });
    assert.equal(ops.length, 2);
    assert.equal(ops[0].op, 'create');
    assert.equal(ops[0].parent, null);
    const p = buildGoalsPrompt({ charName: 'Alice', userName: 'Bob', card: null, cardChars: 0, goals: [], closedGoals: [{ status: 'done', text: 'old goal' }], memories: [], transcript: 'Bob: hi' });
    assert.match(p.user, /do not recreate/);
    assert.match(p.user, /\(done\) old goal/);
    assert.match(p.user, /normal state|none/);
});

test('injection includes goals as soft, never-forced wants', () => {
    const out = buildInjection({ charName: 'Alice', goals: [{ text: 'Find out why he fears storms' }], memories: [], maxChars: 1000 });
    assert.match(out, /never force it/);
    assert.match(out, /Find out why he fears storms/);
});

// ---------------- initiative ----------------

const base = ({ init: initOver, ...over } = {}) => ({
    init: { ...mergeSettings({ initiative: { mode: 'moderate' } }).initiative, ...(initOver || {}) },
    st: emptyInitiativeState(), now: new Date(2026, 5, 1, 14, 0).getTime(),
    messages: [{ is_user: true, mes: 'bye' }, { is_user: false, mes: 'see you' }],
    lastActivityAt: new Date(2026, 5, 1, 12, 0).getTime(), composing: false, generating: false, ...over,
});

test('initiative limits by mode', () => {
    assert.equal(initiativeLimits({ mode: 'off' }), null);
    assert.deepEqual(initiativeLimits({ mode: 'rare' }), { minGapMin: 240, maxPerDay: 2 });
    assert.deepEqual(initiativeLimits({ mode: 'custom', customMinGapMin: 33, customMaxPerDay: 7 }), { minGapMin: 33, maxPerDay: 7 });
});

test('canReachOut: allowed after real silence, blocked in every protective case', () => {
    assert.equal(canReachOut(base()).ok, true);
    assert.equal(canReachOut(base({ init: { mode: 'off' } })).reason, 'initiative-off');
    assert.equal(canReachOut(base({ generating: true })).reason, 'generating');
    assert.equal(canReachOut(base({ composing: true })).reason, 'user-is-typing');
    assert.equal(canReachOut(base({ messages: [] })).reason, 'empty-chat');
    const live = base(); live.lastActivityAt = live.now - 5 * 60000;
    assert.equal(canReachOut(live).reason, 'conversation-is-live');
    assert.equal(canReachOut(base({ lastActivityAt: 0 })).reason, 'silence-unknown');
    const night = base(); night.now = new Date(2026, 5, 1, 2, 0).getTime(); night.lastActivityAt = night.now - 3 * 3600000;
    assert.equal(canReachOut(night).reason, 'quiet-hours');
    const soon = base(); soon.st.lastSentTs = soon.now - 10 * 60000;
    assert.equal(canReachOut(soon).reason, 'too-soon-after-last');
    const cap = base(); rollInitiativeState(cap.st, cap.now); cap.st.sent = 5;
    assert.equal(canReachOut(cap).reason, 'daily-limit');
});

test('anti-spam: an unanswered initiative message blocks the next one', () => {
    const msgs = [{ is_user: true }, { is_user: false }, { is_user: false, initiative: true }];
    assert.equal(countTrailingUnanswered(msgs), 1);
    assert.equal(canReachOut(base({ messages: msgs })).reason, 'unanswered-limit');
    assert.equal(canReachOut(base({ messages: msgs, init: { maxUnanswered: 2 } })).ok, true);
    assert.equal(countTrailingUnanswered([{ is_user: false, initiative: true }, { is_user: true }]), 0);
});

test('manual test ignores timing but never overrides typing, generation or the unanswered limit', () => {
    const live = base(); live.lastActivityAt = live.now - 1000;
    assert.equal(canReachOut(live, { ignoreTiming: true }).ok, true);
    assert.equal(canReachOut(base({ composing: true }), { ignoreTiming: true }).reason, 'user-is-typing');
    assert.equal(canReachOut(base({ messages: [{ is_user: false, initiative: true }] }), { ignoreTiming: true }).reason, 'unanswered-limit');
});

test('idle-check budget: interval and daily cap; counters reset on a new day', () => {
    const c = base();
    assert.equal(idleCheckDue(c).ok, true);
    recordIdleCheck(c.st, c.now);
    assert.equal(idleCheckDue({ ...c, now: c.now + 10 * 60000 }).reason, 'idle-check-interval');
    assert.equal(idleCheckDue({ ...c, now: c.now + 31 * 60000 }).ok, true);
    for (let i = 0; i < 10; i++) recordIdleCheck(c.st, c.now + i);
    assert.equal(idleCheckDue({ ...c, now: c.now + 40 * 60000 }).reason, 'idle-check-daily-cap');
    assert.equal(idleCheckDue({ ...c, now: c.now + DAY }).ok, true);
    recordInitiativeSent(c.st, c.now + DAY);
    assert.equal(c.st.sent, 1);
});

test('generated initiative text is cleaned', () => {
    assert.equal(cleanInitiativeText('Alice: "Hey, are you there?"', 'Alice'), 'Hey, are you there?');
    assert.equal(cleanInitiativeText('```\nhello\n```'), 'hello');
    assert.ok(cleanInitiativeText('x'.repeat(5000)).length <= 1501);
    assert.equal(normalizeIdleResult({ reach_out: 'true', reason: 'r', goal_id: 'g1' }).goalId, 'g1');
    assert.equal(normalizeIdleResult({ reach_out: false }).reachOut, false);
    assert.equal(normalizeIdleResult('x'), null);
    assert.match(buildIdlePrompt({ charName: 'A', userName: 'B', card: null, cardChars: 0, now: T, silenceMs: 3 * 3600000, goals: [], memories: [], transcript: 'B: bye' }).user, /silence for: 3 h/);
});
