import test from 'node:test';
import assert from 'node:assert/strict';
import { buildInjection, buildHeartbeatPrompt, formatTranscript, normalizeDiaryResult, normalizeHeartbeatResult, normalizeMemoryResult } from '../src/prompts.js';

test('formatTranscript keeps the newest messages within budget, in order', () => {
    const msgs = Array.from({ length: 50 }, (_, i) => ({ name: i % 2 ? 'Bob' : 'Alice', mes: `message number ${i} `.repeat(5) }));
    const t = formatTranscript(msgs, { maxChars: 500 });
    assert.ok(t.length <= 700);
    assert.ok(t.includes('message number 49'));
    assert.ok(!t.includes('message number 0 '));
    assert.ok(t.indexOf('number 47') < t.indexOf('number 49'));
});

test('formatTranscript strips html-ish tags', () => {
    assert.equal(formatTranscript([{ name: 'A', mes: 'hi <b>there</b><br>' }]), 'A: hi there');
});

test('heartbeat result: tolerant of string booleans, rejects non-objects', () => {
    assert.equal(normalizeHeartbeatResult('x'), null);
    assert.equal(normalizeHeartbeatResult(null), null);
    const r = normalizeHeartbeatResult({ mood: 'calm', diary: 'true', remember: false, diary_focus: 'f', working_note: 'n' });
    assert.deepEqual(r, { mood: 'calm', revisitId: null, unsaid: null, unsaidResolved: [], diary: true, diaryFocus: 'f', remember: false, goals: false, workingNote: 'n' });
    assert.equal(normalizeHeartbeatResult({ goals: 'true' }).goals, true);
});

test('diary result: JSON preferred, plain prose accepted, JSON-looking junk rejected', () => {
    assert.equal(normalizeDiaryResult({ text: 'Сегодня был странный день.', mood: 'тихо' }, '').text, 'Сегодня был странный день.');
    assert.equal(normalizeDiaryResult(null, 'Today was a strange day, honestly.').text, 'Today was a strange day, honestly.');
    assert.equal(normalizeDiaryResult(null, '{"text": broken json that never ends'), null);
    assert.equal(normalizeDiaryResult(null, 'ok'), null);
});

test('memory result: filters invalid, defaults enums, caps count, accepts bare array', () => {
    const r = normalizeMemoryResult({ memories: [
        { text: 'User has a cat named Pixel', type: 'semantic', confidence: 'confirmed', importance: 4, updates: 'null' },
        { text: 'x' },
        { text: 'Weird enum values here', type: 'nope', confidence: 'nope', importance: 50, updates: 'm_123' },
        { text: 'Third valid memory item' },
    ] }, 2);
    assert.equal(r.length, 2);
    assert.equal(r[0].updates, null);
    assert.equal(r[1].type, 'episodic');
    assert.equal(r[1].importance, 5);
    assert.equal(r[1].updates, 'm_123');
    assert.equal(normalizeMemoryResult([{ text: 'bare array memory' }]).length, 1);
    assert.equal(normalizeMemoryResult({ nothing: 1 }), null);
});

test('injection: empty when nothing to say, respects maxChars, marks uncertain memories', () => {
    assert.equal(buildInjection({ charName: 'Alice', memories: [] }), '');
    const mems = Array.from({ length: 30 }, (_, i) => ({ text: `Memory ${i} ${'x'.repeat(60)}`, confidence: i % 2 ? 'uncertain' : 'confirmed' }));
    const out = buildInjection({ charName: 'Alice', mood: 'warm', workingNote: 'thinking', memories: mems, diaryEntry: { text: 'diary text '.repeat(100) }, maxChars: 600 });
    assert.ok(out.length <= 620, `length ${out.length}`);
    assert.ok(out.endsWith(']'));
    assert.ok(out.includes('(uncertain)'));
    assert.ok(out.startsWith('[Private continuity notes for Alice'));
});

test('heartbeat prompt can omit the character card (privacy)', () => {
    const p = buildHeartbeatPrompt({ charName: 'A', userName: 'B', card: null, cardChars: 0, transcript: 'B: hi', recentDiary: [], memories: [], now: 1 });
    assert.ok(p.user.includes('(not provided)'));
    assert.ok(p.system.includes('JSON'));
});
