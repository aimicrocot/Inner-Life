import test from 'node:test';
import assert from 'node:assert/strict';
import { addDiaryEntry, addMemory, deleteMemory, emptyCharData, enforceMemoryLimit, markRecalled, migrateCharData, retrieveMemories, searchDiary, updateDiaryEntry, updateMemory } from '../src/store.js';

const T = 1_800_000_000_000;
const fresh = () => emptyCharData('A.png', 'Alice', T);

test('diary: rejects tiny entries, filters by chat/query, sorts', () => {
    const d = fresh();
    assert.equal(addDiaryEntry(d, { text: 'hi' }, T), null);
    addDiaryEntry(d, { text: 'Сегодня он впервые рассказал о сестре.', chatId: 'c1', tags: ['семья'] }, T + 1000);
    addDiaryEntry(d, { text: 'Мы поссорились из-за пустяка.', chatId: 'c2' }, T + 2000);
    assert.equal(searchDiary(d).length, 2);
    assert.equal(searchDiary(d)[0].chatId, 'c2');
    assert.equal(searchDiary(d, { order: 'asc' })[0].chatId, 'c1');
    assert.equal(searchDiary(d, { chatId: 'c1' }).length, 1);
    assert.equal(searchDiary(d, { query: 'СЕСТР' }).length, 1);
    assert.equal(searchDiary(d, { query: 'семья' }).length, 1);
    assert.equal(d.state.lastDiaryTs, T + 2000);
});

test('diary: user edit is flagged', () => {
    const d = fresh();
    const e = addDiaryEntry(d, { text: 'Original thought here.' }, T);
    updateDiaryEntry(d, e.id, 'Changed by user', T + 1);
    assert.equal(d.diary[0].edited, true);
});

test('memory: validation', () => {
    const d = fresh();
    assert.equal(addMemory(d, { text: 'no' }, T).action, 'skipped');
    const r = addMemory(d, { text: 'User is allergic to peanuts', type: 'bogus', confidence: 'bogus', importance: 99 }, T);
    assert.equal(r.action, 'added');
    assert.equal(r.memory.type, 'episodic');
    assert.equal(r.memory.confidence, 'inferred');
    assert.equal(r.memory.importance, 5);
});

test('memory: near-duplicates merge and keep history instead of piling up', () => {
    const d = fresh();
    addMemory(d, { text: 'User loves black coffee in the morning', confidence: 'inferred', importance: 2 }, T);
    const r = addMemory(d, { text: 'The user loves black coffee in the morning, always without sugar', confidence: 'confirmed', importance: 3 }, T + 10, { similarityThreshold: 0.6 });
    assert.equal(r.action, 'merged');
    assert.equal(d.memories.length, 1);
    assert.equal(d.memories[0].confidence, 'confirmed');
    assert.equal(d.memories[0].importance, 3);
    assert.equal(d.memories[0].seen, 2);
    assert.equal(d.memories[0].history.length, 1);
    assert.match(d.memories[0].history[0].text, /^User loves black coffee/);
});

test('memory: unrelated memories stay separate', () => {
    const d = fresh();
    addMemory(d, { text: 'User has a younger sister named Mira' }, T);
    assert.equal(addMemory(d, { text: 'We promised to visit the lighthouse together' }, T).action, 'added');
    assert.equal(d.memories.length, 2);
});

test('memory: edits are tracked and user edits mark the memory as user-owned', () => {
    const d = fresh();
    const m = addMemory(d, { text: 'User lives in Berlin' }, T).memory;
    updateMemory(d, m.id, { text: 'User lives in Hamburg', importance: 4 }, T + 5, { by: 'user' });
    assert.equal(m.text, 'User lives in Hamburg');
    assert.equal(m.userEdited, true);
    assert.equal(m.history.at(-1).text, 'User lives in Berlin');
    assert.equal(updateMemory(d, 'nope', {}, T), null);
});

test('memory: auto-archive keeps protected memories and archives lowest-value first, never deletes', () => {
    const d = fresh();
    const keep = addMemory(d, { text: 'Very important promise to protect the village', importance: 5 }, T).memory;
    const pinned = addMemory(d, { text: 'Pinned trivia about weather preferences', importance: 1 }, T).memory;
    pinned.pinned = true;
    for (let i = 0; i < 6; i++) addMemory(d, { text: `Minor detail number ${i} zebra${i} quokka${i}`, importance: 1 }, T + i);
    const archived = enforceMemoryLimit(d, 4, T + 1000);
    assert.equal(archived, 4);
    assert.equal(d.memories.length, 8);
    assert.equal(d.memories.filter(m => m.status === 'active').length, 4);
    assert.equal(keep.status, 'active');
    assert.equal(pinned.status, 'active');
});

test('memory: retrieval prefers relevant + important, respects limit and char budget, ignores archived', () => {
    const d = fresh();
    addMemory(d, { text: 'User is afraid of thunderstorms since childhood', importance: 3 }, T);
    addMemory(d, { text: 'User likes jazz music', importance: 3 }, T);
    const a = addMemory(d, { text: 'Archived thunderstorm story', importance: 5 }, T).memory;
    a.status = 'archived';
    const res = retrieveMemories(d, 'There is a thunderstorm tonight', { limit: 1, now: T });
    assert.equal(res.length, 1);
    assert.match(res[0].text, /thunderstorms/);
    const tight = retrieveMemories(d, 'anything', { limit: 10, maxChars: 30, now: T });
    assert.equal(tight.length, 1); // only the short memory fits the character budget
    assert.match(tight[0].text, /jazz/);
    assert.equal(retrieveMemories(d, 'anything', { limit: 10, maxChars: 5, now: T }).length, 0);
});

test('memory: recall counters update only for used ids', () => {
    const d = fresh();
    const m1 = addMemory(d, { text: 'First memory about apples' }, T).memory;
    const m2 = addMemory(d, { text: 'Second memory about oranges' }, T).memory;
    markRecalled(d, [m1.id], T + 9);
    assert.equal(m1.recalls, 1);
    assert.equal(m2.recalls, 0);
});

test('memory: delete', () => {
    const d = fresh();
    const m = addMemory(d, { text: 'Something to forget soon' }, T).memory;
    assert.equal(deleteMemory(d, m.id), true);
    assert.equal(deleteMemory(d, m.id), false);
});

test('migrateCharData repairs broken structure without losing content', () => {
    const d = migrateCharData({ diary: [{ id: 'x', ts: 1, text: 'keep me please', tags: [] }], memories: 'broken', state: null }, 'A.png', 'Alice', T);
    assert.equal(d.diary.length, 1);
    assert.deepEqual(d.memories, []);
    assert.equal(typeof d.state.processed, 'object');
});
