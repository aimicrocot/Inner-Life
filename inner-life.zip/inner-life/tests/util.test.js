import test from 'node:test';
import assert from 'node:assert/strict';
import { fileNameForCharacter, isQuietHour, jaccard, parseJsonLoose, redactSecrets, safeFileKey, tokenize, toBase64Utf8, truncate } from '../src/util.js';

test('safeFileKey yields only characters allowed by SillyTavern file upload', () => {
    for (const a of ['Alice.png', 'Аня Иванова.png', '../../etc/passwd', 'a b c.card.png', '']) {
        assert.match(fileNameForCharacter(a), /^[a-zA-Z0-9_\-.]+$/);
    }
});

test('different avatars never collide even if their slugs match', () => {
    assert.notEqual(safeFileKey('Аня.png'), safeFileKey('Оля.png'));
    assert.notEqual(safeFileKey('a b.png'), safeFileKey('a-b.png'));
});

test('parseJsonLoose handles fences, prose, trailing commas and garbage', () => {
    assert.deepEqual(parseJsonLoose('```json\n{"a":1}\n```'), { a: 1 });
    assert.deepEqual(parseJsonLoose('Sure! Here it is: {"a":1,"b":[1,2,],} Hope that helps'), { a: 1, b: [1, 2] });
    assert.deepEqual(parseJsonLoose('[1,2,3]'), [1, 2, 3]);
    assert.equal(parseJsonLoose('no json here'), null);
    assert.equal(parseJsonLoose(''), null);
    assert.equal(parseJsonLoose(null), null);
});

test('tokenize/jaccard work for Cyrillic and Latin', () => {
    assert.ok(tokenize('Пользователь любит чёрный кофе').includes('кофе'));
    assert.ok(jaccard('User loves black coffee in the morning', 'The user loves black coffee in morning') > 0.7);
    assert.ok(jaccard('Они поссорились из-за обещания', 'Ей нравится дождь') < 0.2);
    assert.equal(jaccard('', 'abc def'), 0);
});

test('redactSecrets removes explicit keys and bearer tokens', () => {
    const out = redactSecrets('failed with key sk-abcdefghijklmnop and Bearer abcdefghijklmnop12 and mysecretkey123', ['mysecretkey123']);
    assert.ok(!out.includes('abcdefghijklmnop'));
    assert.ok(!out.includes('mysecretkey123'));
});

test('quiet hours wrap over midnight and equal bounds mean disabled', () => {
    const at = (h) => new Date(2026, 0, 1, h, 30).getTime();
    assert.equal(isQuietHour(at(23), 22, 7), true);
    assert.equal(isQuietHour(at(3), 22, 7), true);
    assert.equal(isQuietHour(at(12), 22, 7), false);
    assert.equal(isQuietHour(at(12), 9, 17), true);
    assert.equal(isQuietHour(at(12), 5, 5), false);
});

test('toBase64Utf8 round-trips unicode', () => {
    const s = 'Привет, мир 🌍 — dневник';
    assert.equal(Buffer.from(toBase64Utf8(s), 'base64').toString('utf8'), s);
});

test('truncate', () => {
    assert.equal(truncate('abcdef', 4), 'abc…');
    assert.equal(truncate('abc', 4), 'abc');
});
