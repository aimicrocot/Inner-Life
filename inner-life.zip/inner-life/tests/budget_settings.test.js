import test from 'node:test';
import assert from 'node:assert/strict';
import { checkBudget, emptyUsage, recordUsage } from '../src/budget.js';
import { CURRENT_PROFILE_ID, DEFAULT_SETTINGS, getProfileForTask, mergeSettings, newProfile } from '../src/settings.js';

const limits = { backgroundCallsEnabled: true, maxCallsPerHour: 2, maxCallsPerDay: 3, maxOutputTokensPerDay: 100 };
const T = new Date(2026, 5, 1, 10, 0).getTime();

test('hourly limit blocks and resets next hour', () => {
    const u = emptyUsage();
    recordUsage(u, T, 10, 10); recordUsage(u, T, 10, 10);
    assert.deepEqual(checkBudget(u, limits, T), { ok: false, reason: 'hourly-call-limit' });
    assert.equal(checkBudget(u, limits, T + 3600000).ok, true);
});

test('daily call and token limits block; new day resets', () => {
    const u = emptyUsage();
    recordUsage(u, T, 0, 0); recordUsage(u, T + 3600000, 0, 0); recordUsage(u, T + 7200000, 0, 0);
    assert.equal(checkBudget(u, limits, T + 10800000).reason, 'daily-call-limit');
    assert.equal(checkBudget(u, limits, T + 86400000).ok, true);
    const u2 = emptyUsage();
    recordUsage(u2, T, 0, 150);
    assert.equal(checkBudget(u2, limits, T).reason, 'daily-token-limit');
});

test('kill switch blocks everything', () => {
    assert.equal(checkBudget(emptyUsage(), { ...limits, backgroundCallsEnabled: false }, T).reason, 'background-calls-disabled');
});

test('zero limit means unlimited', () => {
    const u = emptyUsage();
    for (let i = 0; i < 50; i++) recordUsage(u, T, 1, 1);
    assert.equal(checkBudget(u, { ...limits, maxCallsPerHour: 0, maxCallsPerDay: 0, maxOutputTokensPerDay: 0 }, T).ok, true);
});

test('mergeSettings: defaults, unknown keys ignored, ranges clamped, bad assignments repaired', () => {
    const s = mergeSettings({
        enabled: true,
        evil: 1,
        heartbeat: { intervalMin: -5, minNewMessages: 9999 },
        models: { profiles: [{ id: 'p1', name: 'x', type: 'openai' }], assign: { heartbeat: 'p1', diary: 'ghost' } },
        characters: { 'A.png': { enabled: true } },
    });
    assert.equal(s.enabled, true);
    assert.equal(s.evil, undefined);
    assert.equal(s.heartbeat.intervalMin, 1);
    assert.equal(s.heartbeat.minNewMessages, 200);
    assert.ok(s.models.profiles.some(p => p.id === CURRENT_PROFILE_ID));
    assert.equal(s.models.assign.heartbeat, 'p1');
    assert.equal(s.models.assign.diary, CURRENT_PROFILE_ID);
    assert.equal(s.characters['A.png'].diary, true);
    assert.equal(getProfileForTask(s, 'heartbeat').id, 'p1');
});

test('mergeSettings does not share state with DEFAULT_SETTINGS and survives garbage', () => {
    const a = mergeSettings(null);
    a.heartbeat.intervalMin = 99;
    assert.notEqual(DEFAULT_SETTINGS.heartbeat.intervalMin, 99);
    assert.equal(mergeSettings('garbage').enabled, false);
    assert.equal(mergeSettings({ __proto__: { polluted: true } }).polluted, undefined);
});

test('newProfile creates unique ids', () => {
    assert.notEqual(newProfile().id, newProfile().id);
});
